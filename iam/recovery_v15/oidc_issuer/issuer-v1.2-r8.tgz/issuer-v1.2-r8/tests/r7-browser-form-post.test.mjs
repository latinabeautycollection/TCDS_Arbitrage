// r7: what a real browser does on the sign-in page's form POST (found on staging: ORIGIN_DENIED).
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {sameOriginRequest} from '../src/security-v11.mjs';
const s = readFileSync(new URL('../src/server.mjs', import.meta.url), 'utf8');
const html = s.slice(s.indexOf('function html('), s.indexOf('function browserSecret('));
const ISS = 'https://login-stg.tcdsolutionsgroup.com';

test('the HTML page uses Referrer-Policy same-origin (no-referrer makes browsers send Origin: null on the form POST)', () => {
  assert.match(html, /'referrer-policy':'same-origin'/);
  assert.doesNotMatch(html, /'referrer-policy':'no-referrer'/);
});
test('the origin check itself is unchanged: real origin accepted, null / foreign / cross-site refused', () => {
  assert.equal(sameOriginRequest({origin: ISS, 'sec-fetch-site': 'same-origin'}, ISS), true);
  assert.equal(sameOriginRequest({origin: 'null', 'sec-fetch-site': 'same-origin'}, ISS), false);
  assert.equal(sameOriginRequest({origin: 'https://evil.example', 'sec-fetch-site': 'cross-site'}, ISS), false);
  assert.equal(sameOriginRequest({origin: ISS, 'sec-fetch-site': 'same-site'}, ISS), false);
});
test('JSON responses keep no-referrer; form-action allows exactly self + the registered client origin', () => {
  assert.match(s, /function safeJson\(res,status,data,headers=\{\}\)\{if\(status>=400&&res\.tcdsNavigation\)return errorPage\(res,status,res\.tcdsReason\|\|data\?\.error\);res\.writeHead\(status,\{[^}]*'referrer-policy':'no-referrer'/);
  assert.match(s, /form-action 'self' \$\{new URL\(redirect\)\.origin\}; frame-ancestors 'none'/);
});
