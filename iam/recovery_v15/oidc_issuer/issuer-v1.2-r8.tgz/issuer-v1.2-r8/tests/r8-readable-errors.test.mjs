// r8: a person in a browser gets a readable page on any error, never raw JSON; API callers keep JSON.
// End-to-end proof (real server.mjs + oidc-provider): r6_full_flow/deny.mjs in the deploy package.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const s = readFileSync(new URL('../src/server.mjs', import.meta.url), 'utf8');
test('errors on browser navigations render the page; everything else keeps JSON', () => {
  assert.match(s, /const isNavigation=req=>req\.headers\['sec-fetch-mode'\]==='navigate'\|\|\(!req\.headers\['sec-fetch-mode'\]&&\/text\\\/html\/\.test/);
  assert.match(s, /res\.tcdsNavigation=isNavigation\(req\);/);
  assert.match(s, /if\(status>=400&&res\.tcdsNavigation\)return errorPage\(res,status,res\.tcdsReason\|\|data\?\.error\)/);
});
test("the provider's own errors use the same page (renderError)", () => {
  assert.match(s, /async renderError\(ctx,out\)\{const p=errorPageParts\(out\?\.error\);/);
});
test('the page shows fixed text only, a random reference, the strict page CSP, and links back to the EOC', () => {
  const fn = s.slice(s.indexOf('export function errorPageParts('), s.indexOf('function errorPage('));
  assert.match(fn, /randomBytes\(4\)\.toString\('hex'\)/);
  assert.match(fn, /'content-security-policy':PAGE_CSP/);
  assert.match(fn, /new URL\(redirect\)\.origin\+'\/'/);
  assert.doesNotMatch(fn, /req\.|details\.|uid/);   // nothing from the request is echoed
});
test('a refused passkey reads as "no access", stale links read as "expired"', () => {
  assert.match(s, /IAM_VERIFIER_DENIED:'ACCESS'/);
  assert.match(s, /invalid_request:'EXPIRED'/);
  assert.match(s, /SessionNotFound:'EXPIRED'/);
});
