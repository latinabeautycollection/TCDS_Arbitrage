# BFF compatibility overlay — integrate, do not replace deployed BFF

The deployed EOC BFF source is not present in this issuer ZIP or verified GitHub tree. The helper implements the issuer's strict authorization-parameter requirements and post-verification mapping gate; it is not an authentication replacement. BFF MUST:

1. Generate server-side unpredictable `state`, `nonce`, and PKCE verifier; store them server-side and bind to the browser login flow.
2. Use `requiredAuthorizationParams()` or equivalent including `prompt=login`, `max_age=0`, required ACR, and S256.
3. Validate the ID token cryptographically using a pinned issuer, issuer JWKS, signature algorithm, correct audience, current key, nonce, and auth_time before calling `reconcileVerifiedIdToken()`.
4. Use verified opaque `sub` (NOT a UUID assumption), resolve via private 623 bridge, recheck IAM active/epoch; then check enterprise_org appointment plus explicit EOC grants through existing EOC business authority. Do not automatically grant privileges from this helper.
5. Use `SELECT eoc_iam.db_ready_v12()` for DB readiness as Praise staged and tested.
6. Do not enable BFF login before actual issuer, IAM WebAuthn begin/finish, private proxy and stage integrations pass.
