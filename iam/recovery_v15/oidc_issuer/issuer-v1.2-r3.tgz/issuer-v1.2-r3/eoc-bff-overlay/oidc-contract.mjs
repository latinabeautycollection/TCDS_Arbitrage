/** Pure integration contract for the existing EOC BFF, NOT a replacement session authority. */
import {REQUIRED_ACR} from '../src/policy.mjs';
export function requiredAuthorizationParams({clientId,redirectUri,pkceChallenge,state,nonce}){
 for(const x of [clientId,redirectUri,state,nonce])if(typeof x!=='string'||x.length<12)throw Error('OIDC_REQUEST_BINDING_MISSING');
 if(!/^[-_A-Za-z0-9]{43}$/.test(pkceChallenge||''))throw Error('PKCE_S256_CHALLENGE_REQUIRED');
 if(new URL(redirectUri).protocol!=='https:')throw Error('HTTPS_REDIRECT_REQUIRED');
 return {client_id:clientId,redirect_uri:redirectUri,response_type:'code',scope:'openid',code_challenge_method:'S256',code_challenge:pkceChallenge,state,nonce,prompt:'login',max_age:'0',acr_values:REQUIRED_ACR};
}
/** Call only AFTER the BFF's real cryptographic ID-token, nonce, issuer and audience verifier. */
export async function reconcileVerifiedIdToken({verifiedClaims,configuredIssuer,configuredAudience,resolveFederation,readIamSubject}){
 if(!verifiedClaims||verifiedClaims.iss!==configuredIssuer||verifiedClaims.aud!==configuredAudience||typeof verifiedClaims.sub!=='string'||!verifiedClaims.sub||verifiedClaims.acr!==REQUIRED_ACR||!Array.isArray(verifiedClaims.amr)||!verifiedClaims.amr.includes('webauthn')||!Number.isSafeInteger(verifiedClaims.auth_time))throw Error('OIDC_CLAIMS_INSUFFICIENT');
 if(Date.now()/1000-verifiedClaims.auth_time>120||verifiedClaims.auth_time>Date.now()/1000+5)throw Error('OIDC_AUTHENTICATION_STALE');
 const subject=await resolveFederation({issuer:verifiedClaims.iss,providerSubject:verifiedClaims.sub});
 if(!subject?.userId||subject.verified!==true)throw Error('OIDC_SUBJECT_UNMAPPED');
 const iam=await readIamSubject(subject.userId);
 if(iam?.userId!==subject.userId||iam.active!==true||!Number.isSafeInteger(iam.epoch)||iam.epoch<0)throw Error('IAM_SUBJECT_INACTIVE');
 return {iamUserId:subject.userId,epoch:iam.epoch};
}
