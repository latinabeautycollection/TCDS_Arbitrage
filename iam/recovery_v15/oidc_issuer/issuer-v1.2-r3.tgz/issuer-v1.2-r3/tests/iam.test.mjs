import test from 'node:test';import assert from 'node:assert/strict';
import {signWorkload,createIamVerifier} from '../src/iam-verifier-client.mjs';
import {REQUIRED_ACR} from '../src/policy.mjs';
const env={IAM_PASSKEY_API_URL:'https://iam.internal',IAM_WORKLOAD_KEY:'k'.repeat(40),IAM_CA_FILE:'ca',IAM_CLIENT_CERT:'cert',IAM_CLIENT_KEY:'key'};
test('HMAC signs method, path, timestamp, nonce, and exact body',()=>{
 const p=['k'.repeat(40),'POST','/internal/v1/iam/oidc/passkey/begin','123','nonce',Buffer.from('{}')];
 const sig=signWorkload(...p);assert.match(sig,/^[a-f0-9]{64}$/);
 for(const i of [1,2,3,4,5]){const v=[...p];v[i]=i===5?Buffer.from('{ }'):String(v[i])+'2';assert.notEqual(signWorkload(...v),sig)}
});
test('verifier client routes exact begin path and returns central options',async()=>{
 let path;const client=createIamVerifier(env,async(url,request)=>{path=url.pathname;assert.equal(request.headers['content-type'],'application/json');return {challengeId:'abc',options:{challenge:'base64'}}});
 const got=await client.begin({interactionId:'abc',requestId:'xyz',issuer:'https://login-stg.tcdsolutionsgroup.com'});
 assert.equal(path,'/internal/v1/iam/oidc/passkey/begin');assert.equal(got.challengeId,'abc');
});
test('finish denies fake verifier result and does not synthesize identity',async()=>{
 const client=createIamVerifier(env,async()=>({subject:'fake'}));
 await assert.rejects(client.finish({interactionId:'x',requestId:'req',issuer:'https://login-stg.tcdsolutionsgroup.com',challengeId:'chall',credential:{}}),/IAM_PASSKEY_PROOF_BINDING_INVALID/);
});
test('finish validates real central assurance fields',async()=>{
 const now=Math.floor(Date.now()/1000);const client=createIamVerifier(env,async()=>({verifier:'TCDS_CENTRAL_IAM_WEBAUTHN',action:'EOC_OIDC_LOGIN',interactionId:'x',issuer:'https://login-stg.tcdsolutionsgroup.com',requestId:'req',challengeId:'chall',subject:'issuer-subject-12345',iamUserId:'123e4567-e89b-42d3-a456-426614174000',evidenceId:'verified_0123',userVerified:true,rpVerified:true,originVerified:true,counterOrBackupPolicyPassed:true,credentialActive:true,accountActive:true,bindingVerified:true,acr:REQUIRED_ACR,amr:['webauthn','user_verification'],authTime:now,expiresAt:now+100}));
 const x=await client.finish({interactionId:'x',requestId:'req',issuer:'https://login-stg.tcdsolutionsgroup.com',challengeId:'chall',credential:{}});assert.equal(x.accountId,'issuer-subject-12345');
});
