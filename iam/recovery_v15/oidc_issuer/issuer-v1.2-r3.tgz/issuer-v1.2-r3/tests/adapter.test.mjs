import test from 'node:test';import assert from 'node:assert/strict';
import {createCentralIamOidcPasskeyHandlers} from '../src/central-iam-route-adapter.mjs';
const issuer='https://login-stg.tcdsolutionsgroup.com',requestId='123e4567-e89b-42d3-a456-426614174000',userId='123e4567-e89b-42d3-a456-426614174111';
const data={interactionId:'interaction-123',requestId,issuer,purpose:'EOC_OIDC_LOGIN',challengeId:'challenge',credential:{id:'test-key'}};
function setup(overrides={}){const source={assertPrivateWorkload:async()=>{},allowedIssuer:issuer,allowedOrigin:issuer,allowedRpId:'login-stg.tcdsolutionsgroup.com',centralWebAuthn:{begin:async()=>({challengeId:'challenge',options:{challenge:'nonce',userVerification:'required'}}),finish:async()=>({signatureVerified:true,challengeVerified:true,originVerified:true,rpIdVerified:true,userVerified:true,counterOrBackupPolicyPassed:true,credentialActive:true,authTime:Math.floor(Date.now()/1000),evidenceId:'e-1',userId,issuerSubject:'opaque-subject-12345'})},resolve623Binding:async()=>({userId,verified:true}),loadIamStatus:async()=>({active:true}),...overrides};return createCentralIamOidcPasskeyHandlers(source)}
test('begin calls centrally configured WebAuthn challenge',async()=>assert.equal((await setup().begin({json:data})).challengeId,'challenge'));
test('finish accepts central verifier proof + 623 bound subject',async()=>assert.equal((await setup().finish({json:data})).subject,'opaque-subject-12345'));
test('rejects unconnected central verifier',()=>assert.throws(()=>createCentralIamOidcPasskeyHandlers({}),/VERIFIER_INTEGRATION_REQUIRED/));
for(const p of [{purpose:'OTHER'},{issuer:'https://evil.test'},{interactionId:'../'},{requestId:'wrong'}])test('rejects invalid central request',async()=>assert.rejects(setup().begin({json:{...data,...p}})));
test('unauthenticated private workload denied',async()=>assert.rejects(setup({assertPrivateWorkload:async()=>{throw Error('WORKLOAD_DENIED')}}).finish({json:data}),/WORKLOAD_DENIED/));
for(const key of ['signatureVerified','challengeVerified','originVerified','rpIdVerified','userVerified','credentialActive','counterOrBackupPolicyPassed'])test('refuses verifier missing '+key,async()=>{
 const base={signatureVerified:true,challengeVerified:true,originVerified:true,rpIdVerified:true,userVerified:true,credentialActive:true,counterOrBackupPolicyPassed:true,evidenceId:'e-1',userId,issuerSubject:'opaque-subject-12345'};
 const h=setup({centralWebAuthn:{begin:async()=>({}),finish:async()=>({...base,[key]:false})}});await assert.rejects(h.finish({json:data}),/ASSERTION_REJECTED/)
});
test('suspended IAM account denied',async()=>assert.rejects(setup({loadIamStatus:async()=>({active:false})}).finish({json:data}),/IAM_ACCOUNT_INACTIVE/));
test('wrong issuer-subject binding denied',async()=>assert.rejects(setup({resolve623Binding:async()=>({userId:'wrong',verified:true})}).finish({json:data}),/SUBJECT_BINDING_DENIED/));
