import test from 'node:test';import assert from 'node:assert/strict';
import {loginSetting,PATHS_WHEN_LOGIN_DISABLED,requiredEnv} from '../src/policy.mjs';
import {createIamVerifier,signWorkload} from '../src/iam-verifier-client.mjs';

// FIX 1: login gate fails closed
test('login gate: exact "true" enables',()=>assert.deepEqual({...loginSetting({OIDC_LOGIN_ENABLED:'true'})},{enabled:true,valid:true}));
test('login gate: "false" disables (valid)',()=>assert.deepEqual({...loginSetting({OIDC_LOGIN_ENABLED:'false'})},{enabled:false,valid:true}));
for(const v of [undefined,'','TRUE','True','yes','1',' true','true '])
 test(`login gate: ${JSON.stringify(v)} disables and is flagged invalid`,()=>assert.deepEqual({...loginSetting({OIDC_LOGIN_ENABLED:v})},{enabled:false,valid:false}));
test('login gate: only discovery, JWKS and health are served while disabled',()=>assert.deepEqual([...PATHS_WHEN_LOGIN_DISABLED].sort(),
 ['/.well-known/openid-configuration','/internal/health/live','/internal/health/ready','/jwks']));
for(const p of ['/auth','/token','/interaction/abcdefgh','/interaction/abcdefgh/complete','/me','/session/end','/token/revocation','/reg'])
 test(`login gate: ${p} is not served while disabled`,()=>assert.equal(PATHS_WHEN_LOGIN_DISABLED.has(p),false));
const base={OIDC_RUNTIME_ENABLED:'true',OIDC_ISSUER:'https://login-stg.tcdsolutionsgroup.com/',OIDC_CLIENT_ID:'tcds-eoc-stg',OIDC_CLIENT_SECRET:'a'.repeat(48),
 OIDC_REDIRECT_URI:'https://eoc-stg.tcdsolutionsgroup.com/api/eoc/auth/callback',OIDC_JWKS_FILE:'/tmp/key',OIDC_DB_CA_FILE:'ca',OIDC_COOKIE_KEYS:'a'.repeat(40)+','+'b'.repeat(40),
 OIDC_DATABASE_URL:'postgresql://user:password@issuer-db.internal/issuer',IAM_PASSKEY_API_URL:'https://iam-internal-stg.tcdsolutionsgroup.com',IAM_WORKLOAD_KEY:'d'.repeat(40),
 IAM_EOC_BRIDGE_KEY:'f'.repeat(40),OIDC_PASSKEY_SIGNING_KEY:'e'.repeat(40),IAM_CA_FILE:'ca',IAM_CLIENT_CERT:'cert',IAM_CLIENT_KEY:'key'};
test('runtime enabled + login setting missing: starts with login disabled',()=>{const r=requiredEnv(base);assert.equal(r.login.enabled,false);assert.equal(r.login.valid,false)});
test('runtime disabled: refuses to start',()=>assert.throws(()=>requiredEnv({...base,OIDC_RUNTIME_ENABLED:'false'}),/ISSUER_RUNTIME_DISABLED/));
test('legacy OIDC_PRODUCTION_ENABLED alone no longer starts the issuer',()=>{const {OIDC_RUNTIME_ENABLED,...legacy}=base;assert.throws(()=>requiredEnv({...legacy,OIDC_PRODUCTION_ENABLED:'true'}),/ISSUER_RUNTIME_DISABLED/)});

// FIX 3: UUID nonces, signed exactly as sent
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const env={IAM_PASSKEY_API_URL:'https://iam.test',IAM_EOC_BRIDGE_API_URL:'https://bridge.test',IAM_WORKLOAD_KEY:'w'.repeat(48),IAM_EOC_BRIDGE_KEY:'k'.repeat(48),
 IAM_CA_FILE:'ca',IAM_CLIENT_CERT:'cert',IAM_CLIENT_KEY:'key'};
function capture(){
 const calls=[];
 const post=async(url,{raw,headers,method='POST'})=>{calls.push({url,raw,headers,method});
  if(url.pathname.endsWith('/ready'))return {ready:true,epochAuthority:true,federationAuthority:true};
  if(url.pathname.endsWith('/federation/resolve'))return {verified:true,userId:'123e4567-e89b-42d3-a456-426614174000'};
  if(url.pathname.includes('/subject/'))return {userId:'123e4567-e89b-42d3-a456-426614174000',active:true,epoch:4};
  return {challengeId:'c'.repeat(16),options:{challenge:'x'}};};
 return {calls,post};
}
test('every bridge/passkey call sends a UUID nonce and signs that exact nonce',async()=>{
 const {calls,post}=capture();const v=createIamVerifier(env,post);
 await v.readiness();
 await v.checkSubject({issuer:'https://login-stg.tcdsolutionsgroup.com',subject:'v1.opaque-subject-123456'});
 await v.begin({interactionId:'interaction_1',requestId:'123e4567-e89b-42d3-a456-426614174001',issuer:'https://login-stg.tcdsolutionsgroup.com'});
 assert.equal(calls.length,4);
 for(const c of calls){
  const n=c.headers['x-eoc-workload-nonce'],ts=c.headers['x-eoc-workload-timestamp'];
  assert.match(n,UUID,`nonce for ${c.url.pathname}`);
  const key=c.url.pathname.startsWith('/internal/v1/iam/oidc/')?env.IAM_WORKLOAD_KEY:env.IAM_EOC_BRIDGE_KEY;
  assert.equal(c.headers['x-eoc-workload-signature'],signWorkload(key,c.method,c.url.pathname,ts,n,c.raw),`signature for ${c.url.pathname}`);
 }
 assert.equal(new Set(calls.map(c=>c.headers['x-eoc-workload-nonce'])).size,4,'nonces are unique');
});
