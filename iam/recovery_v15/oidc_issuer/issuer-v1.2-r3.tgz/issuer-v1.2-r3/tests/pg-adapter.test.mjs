import test from 'node:test';import assert from 'node:assert/strict';import {createAdapterFactory} from '../src/pg-adapter.mjs';
test('adapter uses atomic SQL for token consume',async()=>{
 let seen='';const factory=createAdapterFactory({query:async(sql)=>{seen=sql;return {rowCount:1,rows:[{id:'x'}]}}});await new factory('AuthorizationCode').consume('x');assert.match(seen,/consumed_at IS NULL/);assert.match(seen,/RETURNING id/);
});
test('adapter rejects repeated consume when SQL updates none',async()=>{
 const factory=createAdapterFactory({query:async()=>({rowCount:0,rows:[]})});await assert.rejects(new factory('AuthorizationCode').consume('x'),/ALREADY_CONSUMED/);
});
test('adapter replay guard uses expired-row-only conditional upsert',async()=>{
 let sql='';const factory=createAdapterFactory({query:async(q)=>{sql=q;return {rowCount:1}}});await new factory('ReplayDetection').upsert('nonce',{},60);assert.match(sql,/WHERE eoc_oidc.artifacts.expires_at<clock_timestamp\(\)/);
});
test('adapter replay guard rejects existing nonce',async()=>{
 const factory=createAdapterFactory({query:async()=>({rowCount:0})});await assert.rejects(new factory('ReplayDetection').upsert('nonce',{},60),/REPLAY_DETECTED/);
});
