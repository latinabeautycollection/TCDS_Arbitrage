import test from 'node:test';import assert from 'node:assert/strict';
import {allowedPasskeyRoute,validateIssuerWorkloadIdentity} from '../src/issuer-passkey-route-policy.mjs';
import {readFileSync} from 'node:fs';
const known=['/internal/v1/iam/oidc/passkey/begin','/internal/v1/iam/oidc/passkey/finish'];
for(const path of known)test('allows only dedicated passkey POST '+path,()=>assert.equal(allowedPasskeyRoute('POST',path),true));
for(const path of ['/internal/v1/iam/eoc/ready','/internal/v1/iam/eoc/subject/abc','/internal/v1/iam/oidc/passkey/finish/other','/internal/v1/iam/oidc/passkey/begin?debug=1','/internal/v1/iam/oidc/passkey/','/internal/v1/iam/oidc/passkey/begin/'])test('rejects unrelated route '+path,()=>assert.equal(allowedPasskeyRoute('POST',path),false));
test('GET to passkey denied',()=>assert.equal(allowedPasskeyRoute('GET',known[0]),false));
const cert={subject:{CN:'tcds-oidc-issuer-staging'},subjectaltname:'URI:spiffe://tcds/staging/oidc-issuer',ext_key_usage:['1.3.6.1.5.5.7.3.2'],fingerprint256:'AB:CD'};
const c={cn:'tcds-oidc-issuer-staging',uri:'spiffe://tcds/staging/oidc-issuer',fingerprints:['AB:CD']};
test('explicit client identity accepted',()=>assert.equal(validateIssuerWorkloadIdentity(cert,c),true));
for(const [k,v] of [['subject',{CN:'wrong'}],['subjectaltname','URI:spiffe://another'],['ext_key_usage',[]],['fingerprint256','CD:EF']])test('wrong client identity denied '+k,()=>assert.equal(validateIssuerWorkloadIdentity({...cert,[k]:v},c),false));
test('existing 623 bridge is not rewritten by proxy changes',()=>{const proxy=readFileSync(new URL('../deploy/issuer-passkey-mtls-proxy.cjs',import.meta.url),'utf8');assert.doesNotMatch(proxy,/warehouse_identity|eoc_resolve_federation_v623/);assert.match(proxy,/127\.0\.0\.1/);assert.match(proxy,/PATHS\.has\(req\.url\)/)});

import {createCentralIamOidcPasskeyHandlers} from '../src/central-iam-route-adapter.mjs';
import {REQUIRED_ACR} from '../src/policy.mjs';
const uuid='123e4567-e89b-42d3-a456-426614174000';
function makeDeps(binding){return {assertPrivateWorkload:async()=>{},centralWebAuthn:{begin:async()=>({challengeId:'some-challenge',options:{challenge:'base64url_challenge',userVerification:'required'}}),finish:async()=>({signatureVerified:true,challengeVerified:true,originVerified:true,rpIdVerified:true,userVerified:true,counterOrBackupPolicyPassed:true,credentialActive:true,evidenceId:'verified_1234',userId:uuid,issuerSubject:'issuer_subject_12345678',authTime:Math.floor(Date.now()/1000)})},resolve623Binding:async()=>binding,loadIamStatus:async()=>({active:true}),allowedIssuer:'https://login-stg.tcdsolutionsgroup.com',allowedOrigin:'https://login-stg.tcdsolutionsgroup.com',allowedRpId:'login-stg.tcdsolutionsgroup.com'}}
const ctx={json:{purpose:'EOC_OIDC_LOGIN',issuer:'https://login-stg.tcdsolutionsgroup.com',interactionId:'abcd1234_xyz',requestId:uuid,challengeId:'some-challenge',credential:{id:'a'}}};
test('623 bridge verified:true JSON is accepted exactly after central passkey signature',async()=>{const h=createCentralIamOidcPasskeyHandlers(makeDeps({verified:true,userId:uuid}));const x=await h.finish(ctx);assert.equal(x.acr,REQUIRED_ACR);assert.equal(x.iamUserId,uuid)});
for(const binding of [null,{verified:false,userId:uuid},{verified:true,userId:'223e4567-e89b-42d3-a456-426614174000'}])test('623 mapping mismatch cannot issue passkey proof '+JSON.stringify(binding),async()=>{const h=createCentralIamOidcPasskeyHandlers(makeDeps(binding));await assert.rejects(h.finish(ctx),/FEDERATED_SUBJECT_BINDING_DENIED/)});
