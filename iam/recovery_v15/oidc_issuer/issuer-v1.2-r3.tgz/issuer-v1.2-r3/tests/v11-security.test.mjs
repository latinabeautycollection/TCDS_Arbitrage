import test from 'node:test';
import assert from 'node:assert/strict';
import {csrfToken,parseIssuerCookies,sameOriginRequest,validatedIssuerKeys} from '../src/security-v11.mjs';
import {createIamVerifier} from '../src/iam-verifier-client.mjs';
import {REQUIRED_ACR,assertPasskeyProof} from '../src/policy.mjs';
import {readFileSync} from 'node:fs';
import {generateKeyPairSync} from 'node:crypto';
const issuer='https://login-stg.tcdsolutionsgroup.com';
const env={IAM_PASSKEY_API_URL:'https://iam.internal',IAM_EOC_BRIDGE_API_URL:'https://iam.internal',IAM_WORKLOAD_KEY:'a'.repeat(48),IAM_EOC_BRIDGE_KEY:'b'.repeat(48),IAM_CA_FILE:'ca',IAM_CLIENT_CERT:'cert',IAM_CLIENT_KEY:'key'};
const uid='interaction_123456789',key='c'.repeat(48),cookie='a'.repeat(64);
test('cookie parser reads only issuer csrf cookie',()=>assert.equal(parseIssuerCookies('hello=x; __Host-tcds_oidc_csrf='+cookie+'; other=y')['__Host-tcds_oidc_csrf'],cookie));
test('cookie parser ignores unrelated cookies',()=>assert.deepEqual(parseIssuerCookies('token=xyz'),{}));
test('csrf tied to browser secret',()=>assert.notEqual(csrfToken(key,uid,cookie),csrfToken(key,uid,'b'.repeat(64))));
test('csrf tied to interaction',()=>assert.notEqual(csrfToken(key,uid,cookie),csrfToken(key,'other_id_1234',cookie)));
test('csrf absent secret denied',()=>assert.equal(csrfToken(key,uid,null),null));
test('csrf invalid hex denied',()=>assert.equal(csrfToken(key,uid,'z'.repeat(64)),null));
test('csrf short HMAC key denied',()=>assert.equal(csrfToken('x',uid,cookie),null));
test('csrf reproducible same browser + interaction',()=>assert.equal(csrfToken(key,uid,cookie),csrfToken(key,uid,cookie)));
test('same-origin browser POST allowed',()=>assert.equal(sameOriginRequest({origin:issuer,'sec-fetch-site':'same-origin'},issuer),true));
for(const h of [{origin:'https://evil.test'}, {}, {origin:issuer,'sec-fetch-site':'cross-site'},{origin:issuer,'sec-fetch-site':'same-site'},{origin:issuer,'sec-fetch-site':'none'}])test('origin rejects '+JSON.stringify(h),()=>assert.equal(sameOriginRequest(h,issuer),false));
const material=generateKeyPairSync('rsa',{modulusLength:3072,publicExponent:65537});
const minimal={...material.privateKey.export({format:'jwk'}),kid:'key-1',alg:'RS256',use:'sig'};
test('RS256 valid private signing metadata accepted',()=>assert.equal(validatedIssuerKeys({keys:[minimal]}).keys[0].kid,'key-1'));
for(const bad of [[{...minimal,kid:undefined}],[{...minimal,alg:'none'}],[{...minimal,d:undefined}],[{...minimal,kty:'EC'}],[{...minimal,n:'short'}],[minimal,minimal]])test('invalid jwks metadata rejected',()=>assert.throws(()=>validatedIssuerKeys({keys:bad})));
test('missing jwks denied',()=>assert.throws(()=>validatedIssuerKeys({keys:[]})));
test('623 federation + subject status accepted with independent signed calls',async()=>{
 const seen=[];
 const client=createIamVerifier(env,async(url,p)=>{seen.push({path:url.pathname,method:p.method||'POST',signature:p.headers['x-eoc-workload-signature']});
  if(url.pathname.endsWith('/federation/resolve'))return {verified:true,userId:'123e4567-e89b-42d3-a456-426614174000'};
  return {userId:'123e4567-e89b-42d3-a456-426614174000',active:true,epoch:0};});
 assert.deepEqual(await client.checkSubject({issuer,subject:'opaque-issuer-subject'}),{userId:'123e4567-e89b-42d3-a456-426614174000',epoch:0});
 assert.equal(seen.length,2);assert.equal(seen[1].method,'GET');assert.equal(seen[0].signature.length,64);
});
for(const reason of ['binding','inactive','wronguser','noepoch'])test('623 subject status fails closed: '+reason,async()=>{
 const client=createIamVerifier(env,async(url)=>{
  if(url.pathname.endsWith('/federation/resolve'))return reason==='binding'?{verified:false}:{verified:true,userId:'123e4567-e89b-42d3-a456-426614174000'};
  if(reason==='inactive')return {userId:'123e4567-e89b-42d3-a456-426614174000',active:false,epoch:0};
  if(reason==='wronguser')return {userId:'different',active:true,epoch:0};
  return {userId:'123e4567-e89b-42d3-a456-426614174000',active:true};});
 await assert.rejects(client.checkSubject({issuer,subject:'opaque-issuer-subject'}));
});
test('subject status rejects malformed subject before request',async()=>{
 const client=createIamVerifier(env,async()=>{throw Error('NETWORK_MUST_NOT_BE_CALLED')});
 await assert.rejects(client.checkSubject({issuer,subject:'..'}),/FEDERATION_SUBJECT_INVALID/);
});
test('bridge readiness checks real federation and epoch authority',async()=>{
 const client=createIamVerifier(env,async()=>({ready:true,epochAuthority:true,federationAuthority:true}));
 assert.equal(await client.readiness(),true);
});
test('bridge readiness fails with partial response',async()=>{
 const client=createIamVerifier(env,async()=>({ready:true,epochAuthority:true}));
 await assert.rejects(client.readiness(),/IAM_BRIDGE_UNREADY/);
});
test('bridge readiness fails on network outage',async()=>{
 const client=createIamVerifier(env,async()=>{throw Error('DOWN')});
 await assert.rejects(client.readiness(),/DOWN/);
});
test('issuer source keeps central password/passkey authority separate',()=>{
 const s=readFileSync(new URL('../src/server.mjs',import.meta.url),'utf8');
 assert.match(s,/import Provider from 'oidc-provider'/);
 assert.match(s,/verifier\.checkSubject/);
 assert.match(s,/assertFreshOidcRequest/);
 assert.doesNotMatch(s,/warehouse_identity\.password_credentials|warehouse_identity\.passkeys/);
});
test('migration 002 adds explicit state and rollback without changing 623',()=>{
 const s=readFileSync(new URL('../sql/002_issuer_v11_hardening.sql',import.meta.url),'utf8');
 assert.match(s,/ADD COLUMN IF NOT EXISTS state/);assert.doesNotMatch(s,/eoc_resolve_federation_v623|ALTER TABLE warehouse_identity/);
});

test('issuer checks verified IAM UUID against 623 mapping before login completion',()=>{const s=readFileSync(new URL('../src/server.mjs',import.meta.url),'utf8');assert.match(s,/admitted\.userId!==login\.iamUserId/);assert.match(s,/provider\.interactionFinished\(req,res,\{login:\{accountId,acr,amr,ts,remember\}/)});
