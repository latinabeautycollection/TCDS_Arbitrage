import {createHmac,createPrivateKey,createPublicKey} from 'node:crypto';
export function parseIssuerCookies(raw='') {const out={};for(const part of String(raw).split(';')){const i=part.indexOf('=');if(i>0){const k=part.slice(0,i).trim();if(k==='__Host-tcds_oidc_csrf')out[k]=part.slice(i+1).trim()}}return out}
export function csrfToken(key,interactionId,browserSecret){
 if(typeof key!=='string'||key.length<32||typeof interactionId!=='string'||!(/^[0-9a-f]{64}$/.test(browserSecret||'')))return null;
 return createHmac('sha256',key).update(`eoc-oidc-v11:${interactionId}:${browserSecret}`).digest('hex');
}
export function sameOriginRequest(headers,issuer){return headers?.origin===issuer&&headers?.['sec-fetch-site']!=='cross-site'&&headers?.['sec-fetch-site']!=='none'&&headers?.['sec-fetch-site']!=='same-site'}
export function validatedIssuerKeys(jwks){
 if(!jwks||!Array.isArray(jwks.keys)||jwks.keys.length===0)throw Error('SIGNING_KEYS_UNAVAILABLE');
 const kids=new Set();for(const k of jwks.keys){if(!k||k.kty!=='RSA'||typeof k.kid!=='string'||!k.kid.trim()||kids.has(k.kid)||k.alg!=='RS256'||k.use!=='sig'||!k.n||!k.e||!k.d||k.n.length<500)throw Error('INVALID_SIGNING_KEY');
  try{const privateKey=createPrivateKey({key:k,format:'jwk'});const publicKey=createPublicKey(privateKey);if(privateKey.asymmetricKeyType!=='rsa'||publicKey.asymmetricKeyDetails?.modulusLength<3072)throw Error('WEAK_RSA_KEY')}catch{throw Error('SIGNING_KEY_MATERIAL_INVALID')}kids.add(k.kid)}return jwks;
}
