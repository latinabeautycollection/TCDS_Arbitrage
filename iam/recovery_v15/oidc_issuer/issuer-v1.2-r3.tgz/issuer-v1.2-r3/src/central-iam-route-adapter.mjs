/** Mount inside the existing private login-v2-api listener ONLY, behind the approved 623
 * HMAC timestamp + nonce replay verifier and private mTLS ingress.
 * Existing central WebAuthn verifier owns actual cryptographic start/finish ceremonies.
 * This code does not mint new credentials or perform alternative signature verification.
 */
import {REQUIRED_ACR} from './policy.mjs';
export function createCentralIamOidcPasskeyHandlers({assertPrivateWorkload,centralWebAuthn,resolve623Binding,loadIamStatus,allowedIssuer,allowedOrigin,allowedRpId}){
 for(const f of [assertPrivateWorkload,centralWebAuthn?.begin,centralWebAuthn?.finish,resolve623Binding,loadIamStatus])if(typeof f!=='function')throw Error('CENTRAL_WEBAUTHN_VERIFIER_INTEGRATION_REQUIRED');
 if(!allowedIssuer?.startsWith('https://')||!allowedOrigin?.startsWith('https://')||!allowedRpId)throw Error('WEBAUTHN_RP_CONFIGURATION_REQUIRED');
 const ids=x=>typeof x==='string'&&/^[A-Za-z0-9_-]{8,160}$/.test(x);
 const reqId=x=>typeof x==='string'&&/^[0-9a-f-]{36}$/i.test(x);
 const validate=(p)=>{if(p?.purpose!=='EOC_OIDC_LOGIN'||p.issuer!==allowedIssuer||!ids(p.interactionId)||!reqId(p.requestId))throw Error('OIDC_PASSKEY_REQUEST_INVALID')};
 return {
  async begin(ctx){
   await assertPrivateWorkload(ctx);const p=ctx.json;validate(p);
   const started=await centralWebAuthn.begin({purpose:'EOC_OIDC_LOGIN',issuer:p.issuer,requestId:p.requestId,interactionId:p.interactionId,rpId:allowedRpId,origin:allowedOrigin,userVerification:'required',expiresSeconds:120});
   if(!started?.challengeId||!started.options?.challenge||started.options.userVerification!=='required')throw Error('CENTRAL_WEBAUTHN_OPTIONS_INVALID');
   return {challengeId:started.challengeId,options:started.options};
  },
  async finish(ctx){
   await assertPrivateWorkload(ctx);const p=ctx.json;validate(p);
   if(typeof p.challengeId!=='string'||!p.credential||typeof p.credential!=='object')throw Error('WEBAUTHN_ASSERTION_MISSING');
   const verified=await centralWebAuthn.finish({purpose:'EOC_OIDC_LOGIN',issuer:p.issuer,requestId:p.requestId,interactionId:p.interactionId,challengeId:p.challengeId,credential:p.credential,rpId:allowedRpId,origin:allowedOrigin,userVerification:'required',consumeOnce:true});
   if(!verified?.signatureVerified||!verified.challengeVerified||!verified.originVerified||!verified.rpIdVerified||!verified.userVerified||!verified.counterOrBackupPolicyPassed||!verified.credentialActive||!verified.evidenceId||!verified.userId)throw Error('CENTRAL_WEBAUTHN_ASSERTION_REJECTED');
   const status=await loadIamStatus(verified.userId);
   if(!status?.active)throw Error('IAM_ACCOUNT_INACTIVE');
   // Existing migration 623 is the ONLY authority that resolves an issuer+subject to IAM UUID.
   const binding=await resolve623Binding({issuer:p.issuer,subject:verified.issuerSubject});
   if(!binding||binding.userId!==verified.userId||binding.verified!==true)throw Error('FEDERATED_SUBJECT_BINDING_DENIED');
   const now=Math.floor(Date.now()/1000);
   if(!Number.isSafeInteger(verified.authTime)||Math.abs(now-verified.authTime)>120)throw Error('CENTRAL_WEBAUTHN_AUTH_TIME_UNVERIFIED');
   return {verifier:'TCDS_CENTRAL_IAM_WEBAUTHN',action:'EOC_OIDC_LOGIN',interactionId:p.interactionId,issuer:p.issuer,requestId:p.requestId,challengeId:p.challengeId,subject:verified.issuerSubject,iamUserId:verified.userId,evidenceId:verified.evidenceId,userVerified:true,rpVerified:true,originVerified:true,counterOrBackupPolicyPassed:true,credentialActive:true,accountActive:true,bindingVerified:true,acr:REQUIRED_ACR,amr:['webauthn','user_verification'],authTime:verified.authTime,expiresAt:now+45};
  }
 };
}
