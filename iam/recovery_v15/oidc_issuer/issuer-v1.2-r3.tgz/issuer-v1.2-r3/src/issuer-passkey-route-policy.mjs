/** Separate issuer workload ingress policy: NEVER expand legacy EOC bridge prefix. */
export const PASSKEY_ROUTES=Object.freeze(new Set([
 '/internal/v1/iam/oidc/passkey/begin','/internal/v1/iam/oidc/passkey/finish'
]));
export function allowedPasskeyRoute(method,path){return method==='POST'&&PASSKEY_ROUTES.has(path)}
export function validateIssuerWorkloadIdentity(cert,{cn,uri,fingerprints=[]}){
 if(!cert||cert.subject?.CN!==cn||cert.subjectaltname!==`URI:${uri}`)return false;
 if(!Array.isArray(cert.ext_key_usage)||!cert.ext_key_usage.includes('1.3.6.1.5.5.7.3.2'))return false;
 return fingerprints.includes(cert.fingerprint256);
}
