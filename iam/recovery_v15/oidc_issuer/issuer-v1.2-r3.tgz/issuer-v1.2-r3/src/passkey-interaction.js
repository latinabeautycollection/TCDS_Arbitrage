// Browser-only WebAuthn ceremony. No password fields, no Warehouse device assertion.
const button=document.getElementById('go'), status=document.getElementById('status');
const uid=location.pathname.split('/')[2];
function decode(v){const s=v.replace(/-/g,'+').replace(/_/g,'/');const raw=atob(s.padEnd(Math.ceil(s.length/4)*4,'='));return Uint8Array.from(raw,c=>c.charCodeAt(0))}
function encode(v){return btoa(String.fromCharCode(...new Uint8Array(v))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
button.onclick=async()=>{
 button.disabled=true;status.textContent='Checking your passkey…';
 try{
  const o=await fetch(`/interaction/${encodeURIComponent(uid)}/options`,{credentials:'same-origin',cache:'no-store'});
  if(!o.ok)throw Error('Unable to start secure sign-in');const {options,csrf}=await o.json();
  options.challenge=decode(options.challenge);
  if(Array.isArray(options.allowCredentials))options.allowCredentials=options.allowCredentials.map(x=>({...x,id:decode(x.id)}));
  const credential=await navigator.credentials.get({publicKey:options});
  if(!credential)throw Error('No passkey selected');
  const response=credential.response;
  const assertion={id:credential.id,type:credential.type,rawId:encode(credential.rawId),response:{clientDataJSON:encode(response.clientDataJSON),authenticatorData:encode(response.authenticatorData),signature:encode(response.signature),userHandle:response.userHandle?encode(response.userHandle):null}};
  // A regular browser POST lets the OIDC provider send its verified redirect through
  // the top-level navigation (fetch() cannot reliably follow an opaque redirect).
  const form=document.createElement('form');form.method='POST';form.action=`/interaction/${encodeURIComponent(uid)}/complete`;
  for(const [name,value] of Object.entries({credential:JSON.stringify(assertion),csrf})){
    const input=document.createElement('input');input.type='hidden';input.name=name;input.value=value;form.appendChild(input);
  }
  document.body.appendChild(form);form.submit();

 }catch(e){status.textContent=e instanceof Error?e.message:'Sign-in failed';button.disabled=false;}
};
