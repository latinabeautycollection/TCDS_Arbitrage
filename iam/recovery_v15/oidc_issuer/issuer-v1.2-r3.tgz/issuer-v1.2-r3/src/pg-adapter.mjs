/** PostgreSQL adapter compatible with oidc-provider v9: dedicated issuer database only. */
export function createAdapterFactory(pool){
 return class PgAdapter{
  constructor(name){this.name=name;}
  async upsert(id,payload,expiresIn){
   const expires=new Date(Date.now()+Math.max(1,expiresIn||3600)*1000);
   if(this.name==='ReplayDetection'){
    const r=await pool.query(`INSERT INTO eoc_oidc.artifacts(model,id,payload,expires_at) VALUES($1,$2,$3,$4)
      ON CONFLICT(model,id) DO UPDATE SET payload=excluded.payload,expires_at=excluded.expires_at
      WHERE eoc_oidc.artifacts.expires_at<clock_timestamp()`,[this.name,id,payload,expires]);
    if(r.rowCount!==1)throw Error('OIDC_REPLAY_DETECTED');return;
   }
   await pool.query(`INSERT INTO eoc_oidc.artifacts(model,id,payload,expires_at) VALUES($1,$2,$3,$4)
    ON CONFLICT(model,id) DO UPDATE SET payload=excluded.payload,expires_at=excluded.expires_at,consumed_at=NULL`,[this.name,id,payload,expires]);
  }
  async find(id){const x=await pool.query(`SELECT payload,consumed_at FROM eoc_oidc.artifacts WHERE model=$1 AND id=$2 AND expires_at>clock_timestamp()`,[this.name,id]);
   if(!x.rows.length)return undefined;return {...x.rows[0].payload,...(x.rows[0].consumed_at?{consumed:Math.floor(new Date(x.rows[0].consumed_at).getTime()/1000)}:{})};}
  async findByUid(uid){return this.findByColumn('uid',uid)}
  async findByUserCode(userCode){return this.findByColumn('userCode',userCode)}
  async findByColumn(field,value){const x=await pool.query(`SELECT payload,consumed_at FROM eoc_oidc.artifacts WHERE model=$1 AND payload->>$2=$3 AND expires_at>clock_timestamp() LIMIT 1`,[this.name,field,value]);
   if(!x.rows.length)return undefined;return {...x.rows[0].payload,...(x.rows[0].consumed_at?{consumed:Math.floor(new Date(x.rows[0].consumed_at).getTime()/1000)}:{})};}
  async consume(id){const r=await pool.query(`UPDATE eoc_oidc.artifacts SET consumed_at=clock_timestamp() WHERE model=$1 AND id=$2 AND consumed_at IS NULL AND expires_at>clock_timestamp() RETURNING id`,[this.name,id]);if(r.rowCount!==1)throw Error('OIDC_ALREADY_CONSUMED');}
  async destroy(id){await pool.query(`DELETE FROM eoc_oidc.artifacts WHERE model=$1 AND id=$2`,[this.name,id]);}
  async revokeByGrantId(grantId){await pool.query(`DELETE FROM eoc_oidc.artifacts WHERE model=$1 AND payload->>'grantId'=$2`,[this.name,grantId]);}
 }
}
