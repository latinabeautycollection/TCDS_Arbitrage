/** Operator-only run ON CENTRAL ISSUER HOST, not in CI, not in chat.
 * Generates EOC confidential client credentials and RS256 signing JWKS.
 * NEVER commit output. Use a hardware-backed KMS for production if possible.
 */
import {generateKeyPairSync,randomBytes,randomUUID} from 'node:crypto';import {writeFileSync,openSync,closeSync,chmodSync,mkdirSync} from 'node:fs';
const dir=process.argv[2];if(!dir?.startsWith('/etc/tcds-issuer/'))throw Error('PASS_PRIVATE_DIRECTORY_UNDER_ETC_TCDS_ISSUER');
mkdirSync(dir,{recursive:true,mode:0o700});
const {privateKey,publicKey}=generateKeyPairSync('rsa',{modulusLength:3072,publicExponent:0x10001});
const kid=randomUUID(),jwk={...privateKey.export({format:'jwk'}),kid,use:'sig',alg:'RS256'};
const clientId='tcds-eoc-stg-'+randomBytes(8).toString('hex');
const config={OIDC_CLIENT_ID:clientId,OIDC_CLIENT_SECRET:randomBytes(48).toString('base64url'),OIDC_COOKIE_KEYS:[randomBytes(48).toString('base64url'),randomBytes(48).toString('base64url')].join(','),OIDC_PASSKEY_SIGNING_KEY:randomBytes(48).toString('base64url')};
writeFileSync(`${dir}/private-signing-jwks.json`,JSON.stringify({keys:[jwk]}),{mode:0o600,flag:'wx'});
writeFileSync(`${dir}/private-client-secrets.json`,JSON.stringify(config),{mode:0o600,flag:'wx'});
writeFileSync(`${dir}/public-registration.json`,JSON.stringify({clientId,redirectUri:'https://eoc-stg.tcdsolutionsgroup.com/api/eoc/auth/callback',requiredAcr:'urn:tcds:acr:phishing-resistant:uv',jwksKid:kid},null,2),{mode:0o640,flag:'wx'});
console.log('Private keys and client secret created under root-controlled directory. No secret printed. Public registration:',`${dir}/public-registration.json`);
