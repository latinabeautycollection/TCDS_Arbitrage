/* Separate IAM-owner-operated mTLS listener for the OIDC issuer only.
 * Existing eocMtlsProxy.cjs and its 623 bridge remain byte-for-byte unchanged.
 * Configure OIDC_PASSKEY_PROXY_CONFIG with absolute paths. No secrets logged.
 * This proxy enforces mTLS/workload identity, route scope and byte limits.
 * The upstream IAM listener MUST independently verify HMAC + DB nonce and central passkeys.
 */
'use strict';
const https=require('node:https'),http=require('node:http'),fs=require('node:fs');
const C=JSON.parse(fs.readFileSync(process.env.OIDC_PASSKEY_PROXY_CONFIG,'utf8'));
const PATHS=new Set(['/internal/v1/iam/oidc/passkey/begin','/internal/v1/iam/oidc/passkey/finish']);
const SIZE=16384;
const SAFE_HEADERS=['content-type','content-length','x-request-id','x-eoc-workload-timestamp','x-eoc-workload-nonce','x-eoc-workload-signature'];
if(!C.identity?.cn||!C.identity?.uri||!C.allowedClients||!Number.isInteger(C.port)||!Number.isInteger(C.upstreamPort)||!C.allowedIps?.length)throw Error('OIDC_PROXY_CONFIGURATION_INCOMPLETE');
const ip=s=>(s.remoteAddress||'').replace(/^::ffff:/,'');
function fingerprints(){try{return new Set(fs.readFileSync(C.allowedClients,'utf8').split(/\r?\n/).map(x=>x.trim().toUpperCase()).filter(x=>/^([0-9A-F]{2}:){31}[0-9A-F]{2}$/.test(x)))}catch{return new Set()}}
function authorized(cert){return cert?.subject?.CN===C.identity.cn&&cert.subjectaltname==='URI:'+C.identity.uri&&(cert.ext_key_usage||[]).includes('1.3.6.1.5.5.7.3.2')&&fingerprints().has(cert.fingerprint256)}
function deny(res,status,reason){if(!res.headersSent)res.writeHead(status,{'content-type':'application/json','cache-control':'no-store'}).end(JSON.stringify({error:reason}));else res.destroy()}
const server=https.createServer({key:fs.readFileSync(C.serverKey),cert:fs.readFileSync(C.serverCert),ca:fs.readFileSync(C.caCert),requestCert:true,rejectUnauthorized:true,minVersion:'TLSv1.3'},(req,res)=>{
 if(!req.socket.authorized||!authorized(req.socket.getPeerCertificate())||!C.allowedIps.includes(ip(req.socket)))return deny(res,403,'WORKLOAD_DENIED');
 if(req.method!=='POST'||!PATHS.has(req.url))return deny(res,404,'ROUTE_NOT_FOUND');
 if(!String(req.headers['content-type']||'').startsWith('application/json'))return deny(res,415,'CONTENT_TYPE_DENIED');
 if(Number(req.headers['content-length']||0)>SIZE)return deny(res,413,'BODY_LIMIT');
 if(!req.headers['x-eoc-workload-signature']||!req.headers['x-eoc-workload-nonce']||!req.headers['x-eoc-workload-timestamp'])return deny(res,401,'WORKLOAD_PROOF_REQUIRED');
 const chunks=[];let total=0;
 req.on('data',part=>{total+=part.length;if(total>SIZE){req.destroy();deny(res,413,'BODY_LIMIT')}else chunks.push(part)});
 req.on('end',()=>{
  if(total>SIZE)return;
  const raw=Buffer.concat(chunks);try{JSON.parse(raw.toString('utf8'))}catch{return deny(res,400,'INVALID_JSON')}
  const headers={};for(const k of SAFE_HEADERS)if(req.headers[k]!==undefined)headers[k]=req.headers[k];headers['content-length']=String(raw.length);
  const up=http.request({host:'127.0.0.1',port:C.upstreamPort,method:'POST',path:req.url,headers,timeout:4000},r=>{
   const response=[];let size=0;r.on('data',b=>{size+=b.length;if(size>32768){up.destroy();deny(res,502,'UPSTREAM_RESPONSE_LIMIT')}else response.push(b)});
   r.on('end',()=>{if(size>32768||res.destroyed)return;res.writeHead(r.statusCode||502,{'content-type':'application/json','cache-control':'no-store'}).end(Buffer.concat(response))});
  });up.on('timeout',()=>up.destroy(Error('TIMEOUT')));up.on('error',()=>deny(res,502,'IAM_UNAVAILABLE'));up.end(raw);
 });
});
server.on('connection',socket=>{if(!C.allowedIps.includes(ip(socket)))socket.destroy()});
server.headersTimeout=8000;server.requestTimeout=12000;
server.listen(C.port,C.listenHost,()=>console.log(JSON.stringify({event:'OIDC_PASSKEY_PROXY_LISTENING',port:C.port})));
