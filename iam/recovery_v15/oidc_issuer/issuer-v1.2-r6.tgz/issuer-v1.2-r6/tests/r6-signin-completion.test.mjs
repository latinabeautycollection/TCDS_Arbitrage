// r6: the three faults that stopped every real browser sign-in after r5, found by driving the full code flow through
// the real server.mjs + oidc-provider (see r6_full_flow/ in the deploy package). These pin the fixes in the source.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const s = readFileSync(new URL('../src/server.mjs', import.meta.url), 'utf8');
const complete = s.slice(s.indexOf('async function complete('), s.indexOf('const js=readFileSync'));

test('completion does not shadow the login gate (r5: "Cannot access \'login\' before initialization")', () => {
  assert.match(complete, /if\(!login\.enabled\)return safeJson\(res,503,\{error:'LOGIN_DISABLED'\}\)/);
  assert.doesNotMatch(complete, /\b(let|const|var)\s+login\b/);
});
test('a verified login records the grant (this client, scope openid) so no second consent interaction opens', () => {
  assert.match(complete, /new provider\.Grant\(\{accountId,clientId:details\.params\.client_id\}\);grant\.addOIDCScope\('openid'\)/);
  assert.match(complete, /consent:\{grantId\}/);
  assert.doesNotMatch(complete, /consent:\{\}/);
  assert.match(complete, /details\.params\.client_id!==env\.OIDC_CLIENT_ID\)return safeJson\(res,403,\{error:'CLIENT_DENIED'\}\)/);
});
test('the ID token carries amr: openid scope claims include amr', () => {
  assert.match(s, /claims:\{acr:null,auth_time:null,sid:null,iss:null,openid:\['sub','amr'\]\}/);
});
test('sign-in page: own stylesheet + logo, same-origin only; CSP adds img-src self and form-action self, nothing else', () => {
  assert.match(s, /href="\/assets\/passkey-interaction\.css"/);
  assert.match(s, /src="\/assets\/tcds-logo-wide\.jpg"/);
  assert.match(s, /default-src 'none'; script-src 'self'; connect-src 'self'; style-src 'self'; img-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'/);
  assert.doesNotMatch(s, /style="/);
  assert.match(s, /id="go"/); assert.match(s, /id="status"/);
});
