import {readFileSync,statSync} from 'node:fs';
import {createServer} from 'node:http';
import {randomUUID,randomBytes} from 'node:crypto';
import {csrfToken, parseIssuerCookies, sameOriginRequest, validatedIssuerKeys} from './security-v11.mjs';
import pg from 'pg';
import Provider from 'oidc-provider';
import {requiredEnv,assertPkce,assertFreshOidcRequest,assertFreshInteraction,REQUIRED_ACR,constantEqual,hashHex,safeUid,servedWhileLoginDisabled} from './policy.mjs';
import {createAdapterFactory} from './pg-adapter.mjs';
import {createIamVerifier} from './iam-verifier-client.mjs';
const env=process.env;
const {issuer,redirect,login}=requiredEnv(env);
if(!login.valid)console.error('OIDC_LOGIN_ENABLED missing or invalid: authentication DENIED (fail closed)');
console.log(`TCDS OIDC issuer login gate: ${login.enabled?'ENABLED':'DISABLED'}`);
const pool=new pg.Pool({connectionString:env.OIDC_DATABASE_URL,ssl:{ca:readFileSync(env.OIDC_DB_CA_FILE,'utf8'),rejectUnauthorized:true},max:10});
// All services must be external and persistent: no in-memory identity, token or passkey store.
await pool.query('SELECT count(*) FROM eoc_oidc.artifacts');
if((statSync(env.OIDC_JWKS_FILE).mode&0o077)!==0)throw Error('SIGNING_KEYS_FILE_PERMISSIONS_TOO_BROAD');
const jwks=validatedIssuerKeys(JSON.parse(readFileSync(env.OIDC_JWKS_FILE,'utf8')));
const verifier=createIamVerifier(env);
const provider=new Provider(issuer,{
 clients:[{client_id:env.OIDC_CLIENT_ID,client_secret:env.OIDC_CLIENT_SECRET,redirect_uris:[redirect],grant_types:['authorization_code'],response_types:['code'],default_acr_values:[REQUIRED_ACR],require_auth_time:true,token_endpoint_auth_method:'client_secret_post',id_token_signed_response_alg:'RS256'}],
 jwks,adapter:createAdapterFactory(pool),
 features:{devInteractions:{enabled:false},registration:{enabled:false},clientCredentials:{enabled:false},deviceFlow:{enabled:false},resourceIndicators:{enabled:false},introspection:{enabled:false}},
 pkce:{required:()=>true}, responseTypes:['code'],
 acrValues:[REQUIRED_ACR], scopes:['openid'], subjectTypes:['public'],
 // r6: the ID token carries only the claims of the granted scope (+ explicitly requested ones); openid covered only sub,
 // so the login's amr was dropped and the EOC (which requires amr incl. webauthn) would refuse every sign-in.
 claims:{acr:null,auth_time:null,sid:null,iss:null,openid:['sub','amr']},
 cookies:{keys:env.OIDC_COOKIE_KEYS.split(',').map(v=>v.trim()),short:{httpOnly:true,sameSite:'lax',secure:true},long:{httpOnly:true,sameSite:'lax',secure:true}},
 ttl:{AuthorizationCode:90,AccessToken:300,IdToken:300,Interaction:180,Session:300},
 interactions:{url:(_ctx,interaction)=>`/interaction/${interaction.uid}`},
 async findAccount(_ctx,id){
   if(!login.enabled)return undefined; // no account => no code/token/claims while login is disabled
   if(!/^[-A-Za-z0-9._~]{16,255}$/.test(id))return undefined;
   // Reverify active account and verified 623 subject binding at issuance/claims time.
   // No cached positive authority and no reliance on email, title or Warehouse device.
   await verifier.checkSubject({issuer,subject:id});
   return {accountId:id,async claims(){await verifier.checkSubject({issuer,subject:id});return {sub:id}}};
 },
 });
provider.proxy=true; // FIX 2 (oidc-provider 9.13): Provider is the Koa app. Trust ONLY the loopback Nginx proxy.
const bindHost='127.0.0.1',bindPort=Number(env.OIDC_PORT||8401);
if(!Number.isInteger(bindPort)||bindPort<1024||bindPort>65535)throw Error('INVALID_PORT');
const allowedHost=new URL(issuer).host;
function safeJson(res,status,data,headers={}){res.writeHead(status,{'content-type':'application/json','cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'no-referrer',...headers});res.end(JSON.stringify(data))}
function html(res,value,extra={}){res.writeHead(200,{...extra,'content-type':'text/html; charset=utf-8','cache-control':'no-store','content-security-policy':"default-src 'none'; script-src 'self'; connect-src 'self'; style-src 'self'; img-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",'x-frame-options':'DENY','referrer-policy':'no-referrer','x-content-type-options':'nosniff'});res.end(value)}
function browserSecret(req){return parseIssuerCookies(req.headers.cookie)['__Host-tcds_oidc_csrf']}
function csrf(uid,req){return csrfToken(env.OIDC_PASSKEY_SIGNING_KEY,uid,browserSecret(req))}
function sameOrigin(req){return sameOriginRequest(req.headers,issuer)}
async function body(req){const ct=req.headers['content-type']?.split(';')[0];if(!['application/json','application/x-www-form-urlencoded'].includes(ct))throw Error('CONTENT_TYPE_REQUIRED');let chunks=[],size=0;for await(const c of req){size+=c.length;if(size>16384)throw Error('BODY_LIMIT');chunks.push(c)}const str=Buffer.concat(chunks).toString('utf8');if(ct==='application/json')return JSON.parse(str);const params=new URLSearchParams(str);return {csrf:params.get('csrf'),credential:JSON.parse(params.get('credential')||'null')}}
async function begin(req,res,uid){
 if(!login.enabled)return safeJson(res,503,{error:'LOGIN_DISABLED'});
 if(!safeUid(uid))return safeJson(res,400,{error:'INVALID_INTERACTION'});
 const details=await provider.interactionDetails(req,res);
 if(details.uid!==uid||details.prompt?.name!=='login')return safeJson(res,403,{error:'LOGIN_REQUIRED'});
 assertPkce(details.params);assertFreshInteraction(details.params);
 if(details.params.client_id!==env.OIDC_CLIENT_ID)return safeJson(res,403,{error:'CLIENT_DENIED'});
 // Reserve BEFORE calling central IAM. At most one issuer replica starts a challenge.
 let hit=await pool.query(`SELECT challenge_id,options,request_id,state FROM eoc_oidc.passkey_interactions WHERE interaction_id=$1 AND expires_at>clock_timestamp() AND consumed_at IS NULL`,[uid]);
 if(!hit.rowCount){
  const requestId=randomUUID(),reservationId=randomUUID();
  const claimed=await pool.query(`INSERT INTO eoc_oidc.passkey_interactions(interaction_id,challenge_id,request_id,options,expires_at,state)
   VALUES($1,$2,$3,'{}'::jsonb,clock_timestamp()+interval '2 minutes','ISSUING') ON CONFLICT(interaction_id) DO UPDATE SET challenge_id=excluded.challenge_id,request_id=excluded.request_id,options=excluded.options,expires_at=excluded.expires_at,state=excluded.state,consumed_at=NULL WHERE eoc_oidc.passkey_interactions.expires_at<clock_timestamp() RETURNING interaction_id`,[uid,reservationId,requestId]);
  if(claimed.rowCount){
   try{
    const issued=await verifier.begin({interactionId:uid,requestId,issuer});
    if(!issued||typeof issued.challengeId!=='string'||!issued.options||typeof issued.options!=='object')throw Error('IAM_BEGIN_BAD_RESPONSE');
    await pool.query(`UPDATE eoc_oidc.passkey_interactions SET challenge_id=$2,options=$3,state='CHALLENGE_ISSUED'
      WHERE interaction_id=$1 AND request_id=$4 AND state='ISSUING'`,[uid,issued.challengeId,issued.options,requestId]);
   }catch(e){await pool.query(`UPDATE eoc_oidc.passkey_interactions SET state='FAILED',consumed_at=clock_timestamp() WHERE interaction_id=$1 AND request_id=$2 AND state='ISSUING'`,[uid,requestId]);throw e}
  }
  hit=await pool.query(`SELECT challenge_id,options,request_id,state FROM eoc_oidc.passkey_interactions WHERE interaction_id=$1 AND expires_at>clock_timestamp() AND consumed_at IS NULL`,[uid]);
 }
 if(!hit.rows[0]||hit.rows[0].state!=='CHALLENGE_ISSUED')return safeJson(res,409,{error:'CHALLENGE_PENDING_OR_EXPIRED'});
 await pool.query(`INSERT INTO eoc_oidc.issuer_security_events(request_id,category,interaction_hash) VALUES($1,$2,$3)`,
  [hit.rows[0].request_id,'LOGIN_CHALLENGE_ISSUED',hashHex(uid)]);
 // A random, HttpOnly browser secret binds the CSRF token to the same issuer browser.
 const existing=browserSecret(req),secret=existing&&/^[0-9a-f]{64}$/.test(existing)?existing:randomBytes(32).toString('hex');
 const cookie=`__Host-tcds_oidc_csrf=${secret}; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=180`;
 // Passkey is requested in the laptop browser; no Warehouse device enrollment.
 return html(res,`<!doctype html><html lang="en"><head><meta charset="utf-8"><title>TCDS · EOC sign-in</title><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><link rel="stylesheet" href="/assets/passkey-interaction.css"></head><body><main class="auth-page"><div class="auth-ambient" aria-hidden="true"></div><section class="auth-layout" aria-label="TCDS EOC sign-in"><div class="auth-showcase"><img class="auth-logo" src="/assets/tcds-logo-wide.jpg" width="830" height="380" alt="TCDS Total Coverage Database Solutions gold shield and wordmark"><span class="auth-overline">ENTERPRISE OPERATIONS CENTER</span><h1>Sign in with<br><em>your passkey.</em></h1><p>Your passkey stays on this laptop and is unlocked only by you. No password is used or sent.</p></div><div class="auth-card signin-card"><span class="signin-kicker"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>TCDS · SECURE SIGN-IN</span><h2>Confirm it's you</h2><p class="lead">Select Use passkey. Your laptop asks for your fingerprint, face or device PIN.</p><ol class="signin-steps"><li><b>1</b><span>Choose <strong>your own</strong> passkey in the list your browser shows.</span></li><li><b>2</b><span>Confirm with fingerprint, face or PIN.</span></li><li><b>3</b><span>You return to the EOC, signed in.</span></li></ol><button id="go" class="auth-submit" type="button">Use passkey</button><p id="status" role="status" aria-live="polite"></p><div class="auth-footer"><span>Encrypted transport required</span><span>Access is centrally governed</span></div></div></section><footer class="auth-page-footer">© 2026 Total Coverage Database Solutions · Authorized personnel only</footer></main><script src="/assets/passkey-interaction.js" defer></script></body></html>`, {'set-cookie':cookie});
}
async function options(req,res,uid){
 if(!safeUid(uid)||req.headers['sec-fetch-site']==='cross-site')return safeJson(res,403,{error:'INVALID_INTERACTION'});
 const details=await provider.interactionDetails(req,res);if(details.uid!==uid||details.prompt?.name!=='login')return safeJson(res,403,{error:'INTERACTION_NOT_AUTHORIZED'});
 const x=await pool.query(`SELECT options FROM eoc_oidc.passkey_interactions WHERE interaction_id=$1 AND expires_at>clock_timestamp() AND consumed_at IS NULL AND state='CHALLENGE_ISSUED'`,[uid]);
 if(!x.rows.length)return safeJson(res,403,{error:'CHALLENGE_EXPIRED'});
 if(!browserSecret(req))return safeJson(res,403,{error:'BROWSER_BINDING_REQUIRED'});
 return safeJson(res,200,{options:x.rows[0].options,csrf:csrf(uid,req)});
}
async function complete(req,res,uid){
 if(!login.enabled)return safeJson(res,503,{error:'LOGIN_DISABLED'});
 if(!sameOrigin(req))return safeJson(res,403,{error:'ORIGIN_DENIED'});
 const details=await provider.interactionDetails(req,res);if(details.uid!==uid||details.prompt?.name!=='login')return safeJson(res,403,{error:'INTERACTION_NOT_AUTHORIZED'});
 assertPkce(details.params);assertFreshInteraction(details.params);
 const data=await body(req);if(!constantEqual(data.csrf,csrf(uid,req))||!data.credential||typeof data.credential!=='object')return safeJson(res,403,{error:'PROOF_REQUIRED'});
 const x=await pool.query(`UPDATE eoc_oidc.passkey_interactions SET state='VERIFYING',consumed_at=clock_timestamp()
 WHERE interaction_id=$1 AND expires_at>clock_timestamp() AND consumed_at IS NULL AND state='CHALLENGE_ISSUED' RETURNING challenge_id,request_id`,[uid]);
 if(x.rowCount!==1)return safeJson(res,401,{error:'CHALLENGE_REPLAY_OR_EXPIRED'});
 let verified; // r6: renamed from "login", which shadowed the module login gate (TDZ error at the gate check above)
 try {verified=await verifier.finish({interactionId:uid,requestId:x.rows[0].request_id,issuer,challengeId:x.rows[0].challenge_id,credential:data.credential});
  // Recheck binding and account state after verification to prevent mid-ceremony revocation.
  const admitted=await verifier.checkSubject({issuer,subject:verified.accountId});
  if(!admitted||admitted.userId!==verified.iamUserId)throw Error('IAM_VERIFIER_SUBJECT_MISMATCH');
  const tx=await pool.connect();
  try {await tx.query('BEGIN');
   await tx.query(`INSERT INTO eoc_oidc.issuer_security_events(request_id,category,interaction_hash) VALUES($1,$2,$3)`,[x.rows[0].request_id,'LOGIN_PASSKEY_VERIFIED',hashHex(uid)]);
   const updated=await tx.query(`UPDATE eoc_oidc.passkey_interactions SET state='VERIFIED' WHERE interaction_id=$1 AND request_id=$2 AND state='VERIFYING' RETURNING interaction_id`,[uid,x.rows[0].request_id]);
   if(updated.rowCount!==1)throw Error('INTERACTION_STATE_CONFLICT');await tx.query('COMMIT');
  }catch(e){await tx.query('ROLLBACK');throw e}finally{tx.release()}
 }catch(e){await pool.query(`UPDATE eoc_oidc.passkey_interactions SET state='FAILED' WHERE interaction_id=$1 AND state='VERIFYING'`,[uid]);throw e}
 // OIDC provider is responsible for code/session issuance. A transient failure here fails
 // terminally and requires a fresh interaction, never reusing the verified challenge.
 const {accountId,acr,amr,ts,remember}=verified;
 // r6: oidc-provider 9 asks for consent unless a Grant covers the request; without one it opened a second
 // ('consent') interaction that begin() refuses (LOGIN_REQUIRED). The EOC is the single registered first-party client
 // and openid the only scope, so the verified login records exactly that grant: this client, scope openid.
 if(details.params.client_id!==env.OIDC_CLIENT_ID)return safeJson(res,403,{error:'CLIENT_DENIED'});
 const grant=new provider.Grant({accountId,clientId:details.params.client_id});grant.addOIDCScope('openid');
 const grantId=await grant.save();
 return provider.interactionFinished(req,res,{login:{accountId,acr,amr,ts,remember},consent:{grantId}},{mergeWithLastSubmission:false});
}
const js=readFileSync(new URL('./passkey-interaction.js',import.meta.url));
// r6: the sign-in page's own stylesheet and logo (same look as the login-stg enrollment page), same-origin only.
const css=readFileSync(new URL('./passkey-interaction.css',import.meta.url)),logo=readFileSync(new URL('./tcds-logo-wide.jpg',import.meta.url));
const server=createServer(async(req,res)=>{
 try{
  const u=new URL(req.url,issuer);
  if(req.headers.host!==allowedHost)return safeJson(res,421,{error:'INVALID_HOST'});
  // FIX 1: server-side login gate, checked before any OIDC route (authorization, token, interaction, passkey).
  if(!login.enabled&&!servedWhileLoginDisabled(req.method,u.pathname))return safeJson(res,503,{error:'LOGIN_DISABLED'});
  if(u.pathname==='/internal/health/live')return safeJson(res,200,{alive:true});
  if(u.pathname==='/internal/health/ready'){
   await pool.query('SELECT 1 FROM eoc_oidc.artifacts LIMIT 1');await verifier.readiness();return safeJson(res,200,{ready:true,database:true,iamBridge:true,issuerConfigured:true,loginEnabled:login.enabled,certified:false});
  }
  if(u.pathname==='/assets/passkey-interaction.css'&&req.method==='GET'){res.writeHead(200,{'content-type':'text/css; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'});return res.end(css)}
  if(u.pathname==='/assets/tcds-logo-wide.jpg'&&req.method==='GET'){res.writeHead(200,{'content-type':'image/jpeg','cache-control':'public, max-age=86400','x-content-type-options':'nosniff'});return res.end(logo)}
  if(u.pathname==='/assets/passkey-interaction.js'&&req.method==='GET'){
    res.writeHead(200,{'content-type':'application/javascript; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'});return res.end(js);
  }
  const m=/^\/interaction\/([A-Za-z0-9_-]{8,160})(?:\/(options|complete))?$/.exec(u.pathname);
  if(m){const [,uid,operation]=m;
   if(req.method==='GET'&&!operation)return await begin(req,res,uid);
   if(req.method==='GET'&&operation==='options')return await options(req,res,uid);
   if(req.method==='POST'&&operation==='complete')return await complete(req,res,uid);
   return safeJson(res,405,{error:'METHOD_NOT_ALLOWED'});
  }
  // Enforce S256 on EVERY authorization request, even when an issuer session already
  // exists and oidc-provider would not otherwise create a login interaction.
  if(u.pathname==='/auth'){
   if(req.method!=='GET')return safeJson(res,405,{error:'METHOD_NOT_ALLOWED'});
   assertPkce(Object.fromEntries(u.searchParams.entries()));assertFreshOidcRequest(Object.fromEntries(u.searchParams.entries()));
   if(u.searchParams.get('client_id')!==env.OIDC_CLIENT_ID)return safeJson(res,400,{error:'UNKNOWN_CLIENT'});
  }
  // oidc-provider is the sole protocol implementation. No custom token or JWKS issuance.
  return provider.callback()(req,res);
 }catch(err){console.error('ISSUER_REQUEST_REJECTED',String(err.message||err).slice(0,80));if(!res.headersSent)return safeJson(res,401,{error:'AUTHENTICATION_UNAVAILABLE'});res.end()}
});
server.listen(bindPort,bindHost,()=>console.log(`TCDS OIDC issuer bound to ${bindHost}:${bindPort}; public issuer ${issuer}`));
process.on('SIGTERM',()=>{server.close(()=>pool.end().finally(()=>process.exit(0)))});
