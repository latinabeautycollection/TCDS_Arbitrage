// r5: the interaction-stage freshness check must accept what oidc-provider 9.x actually stores for a compliant
// request (max_age=0 normalised away into prompt=login), and must still refuse anything that is not a fresh login.
import test from 'node:test';
import assert from 'node:assert/strict';
import {assertFreshOidcRequest,assertFreshInteraction,REQUIRED_ACR} from '../src/policy.mjs';
import {checkMaxAge} from 'oidc-provider/lib/actions/authorization/request_parameters.js';

const raw=()=>({client_id:'c',response_type:'code',scope:'openid',max_age:'0',prompt:'login',acr_values:REQUIRED_ACR,
  code_challenge:'a'.repeat(43),code_challenge_method:'S256'});
async function stored(params){ // oidc-provider's own normalisation, run on the request
  const ctx={oidc:{params:{...params},prompts:new Set(String(params.prompt||'').split(' ').filter(Boolean))}};
  await checkMaxAge(ctx,async()=>{});return ctx.oidc.params;
}

test('a compliant EOC request passes /auth and, after oidc-provider normalises it, the interaction check', async()=>{
  assert.equal(assertFreshOidcRequest(raw()),true);
  const p=await stored(raw());
  assert.equal(p.max_age,undefined);                       // what broke r4: max_age is gone after normalisation
  assert.throws(()=>assertFreshOidcRequest(p),/FRESH_PASSKEY_LOGIN_REQUIRED/);
  assert.equal(assertFreshInteraction(p),true);
});
test('max_age=0 alone is normalised into prompt=login and passes the interaction check', async()=>{
  const p=await stored({...raw(),prompt:undefined});
  assert.match(p.prompt,/login/);assert.equal(assertFreshInteraction(p),true);
});
test('the interaction check still refuses a non-fresh or downgraded request', ()=>{
  assert.throws(()=>assertFreshInteraction({prompt:'consent',acr_values:REQUIRED_ACR}),/FRESH_PASSKEY_LOGIN_REQUIRED/);
  assert.throws(()=>assertFreshInteraction({prompt:'login',max_age:'3600',acr_values:REQUIRED_ACR}),/FRESH_PASSKEY_LOGIN_REQUIRED/);
  assert.throws(()=>assertFreshInteraction({acr_values:REQUIRED_ACR}),/FRESH_PASSKEY_LOGIN_REQUIRED/);
  assert.throws(()=>assertFreshInteraction({prompt:'login'}),/REQUIRED_ACR_MISSING/);
  assert.throws(()=>assertFreshInteraction({prompt:'login',acr_values:'urn:other'}),/REQUIRED_ACR_MISSING/);
  assert.equal(assertFreshInteraction({prompt:'login',max_age:0,acr_values:REQUIRED_ACR}),true);
});
test('/auth stays strict: the raw request must still carry max_age=0 and prompt=login', ()=>{
  assert.throws(()=>assertFreshOidcRequest({...raw(),max_age:undefined}),/FRESH_PASSKEY_LOGIN_REQUIRED/);
  assert.throws(()=>assertFreshOidcRequest({...raw(),prompt:'none'}),/FRESH_PASSKEY_LOGIN_REQUIRED/);
});
test('server.mjs uses the interaction check on both interaction routes and the strict check on /auth', async()=>{
  const fs=await import('node:fs');const s=fs.readFileSync(new URL('../src/server.mjs',import.meta.url),'utf8');
  assert.equal((s.match(/assertFreshInteraction\(details\.params\)/g)||[]).length,2);
  assert.equal((s.match(/assertFreshOidcRequest\(details\.params\)/g)||[]).length,0);
  assert.match(s,/assertFreshOidcRequest\(Object\.fromEntries\(u\.searchParams\.entries\(\)\)\)/);
});
