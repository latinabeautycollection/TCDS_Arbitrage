import test from 'node:test';import assert from 'node:assert/strict';
import {requiredEnv,servedWhileLoginDisabled,PATHS_WHEN_LOGIN_DISABLED} from '../src/policy.mjs';

// r4 hardening adopted from the dev team's V1.4 login-gate.mjs (on top of r3, which already met the three fixes).
const base={OIDC_RUNTIME_ENABLED:'true',OIDC_ISSUER:'https://login-stg.tcdsolutionsgroup.com/',OIDC_CLIENT_ID:'tcds-eoc-stg',OIDC_CLIENT_SECRET:'a'.repeat(48),
 OIDC_REDIRECT_URI:'https://eoc-stg.tcdsolutionsgroup.com/api/eoc/auth/callback',OIDC_JWKS_FILE:'/tmp/key',OIDC_DB_CA_FILE:'ca',OIDC_COOKIE_KEYS:'a'.repeat(40)+','+'b'.repeat(40),
 OIDC_DATABASE_URL:'postgresql://user:password@issuer-db.internal/issuer',IAM_PASSKEY_API_URL:'https://iam-internal-stg.tcdsolutionsgroup.com',IAM_WORKLOAD_KEY:'d'.repeat(40),
 IAM_EOC_BRIDGE_KEY:'f'.repeat(40),OIDC_PASSKEY_SIGNING_KEY:'e'.repeat(40),IAM_CA_FILE:'ca',IAM_CLIENT_CERT:'cert',IAM_CLIENT_KEY:'key'};

for(const v of ['','TRUE','True','yes','1',' true','true ','false ','FALSE','off'])
 test(`r4: OIDC_LOGIN_ENABLED=${JSON.stringify(v)} refuses to start (OIDC_LOGIN_FLAG_INVALID)`,()=>
  assert.throws(()=>requiredEnv({...base,OIDC_LOGIN_ENABLED:v}),/OIDC_LOGIN_FLAG_INVALID/));
test('r4: "false" starts with login disabled',()=>{const r=requiredEnv({...base,OIDC_LOGIN_ENABLED:'false'});assert.equal(r.login.enabled,false);assert.equal(r.login.valid,true)});
test('r4: "true" starts with login enabled',()=>assert.equal(requiredEnv({...base,OIDC_LOGIN_ENABLED:'true'}).login.enabled,true));
test('r4: missing still starts, login disabled (flagged invalid, warning)',()=>{const r=requiredEnv(base);assert.equal(r.login.enabled,false);assert.equal(r.login.valid,false)});

for(const p of PATHS_WHEN_LOGIN_DISABLED){
 test(`r4: GET ${p} is served while login is disabled`,()=>assert.equal(servedWhileLoginDisabled('GET',p),true));
 for(const m of ['POST','PUT','PATCH','DELETE','HEAD','OPTIONS'])
  test(`r4: ${m} ${p} is refused while login is disabled`,()=>assert.equal(servedWhileLoginDisabled(m,p),false));
}
for(const p of ['/auth','/token','/me','/session/end','/interaction/abcdefgh','/.well-known/openid-configuration/','/jwks/','/internal/health'])
 test(`r4: GET ${p} is refused while login is disabled`,()=>assert.equal(servedWhileLoginDisabled('GET',p),false));
