import { timingSafeEqual, createHash } from 'node:crypto';
export const REQUIRED_ACR='urn:tcds:acr:phishing-resistant:uv';
export const ISSUER_PATH='/';
export function requiredEnv(env){
 const needed=['OIDC_ISSUER','OIDC_CLIENT_ID','OIDC_CLIENT_SECRET','OIDC_REDIRECT_URI','OIDC_JWKS_FILE','OIDC_COOKIE_KEYS','OIDC_DATABASE_URL','OIDC_DB_CA_FILE','IAM_PASSKEY_API_URL','IAM_WORKLOAD_KEY','IAM_EOC_BRIDGE_KEY','OIDC_PASSKEY_SIGNING_KEY'];
 for(const key of needed)if(typeof env[key]!=='string'||!env[key].trim())throw Error('MISSING_'+key);
 const issuer=new URL(env.OIDC_ISSUER),redirect=new URL(env.OIDC_REDIRECT_URI),upstream=new URL(env.IAM_PASSKEY_API_URL),dbUrl=new URL(env.OIDC_DATABASE_URL);
 if(!['postgres:','postgresql:'].includes(dbUrl.protocol)||!dbUrl.hostname)throw Error('INVALID_DATABASE_URL');
 if(issuer.protocol!=='https:'||issuer.username||issuer.password||issuer.search||issuer.hash||issuer.pathname!=='/'||redirect.protocol!=='https:'||redirect.pathname!=='/api/eoc/auth/callback'||upstream.protocol!=='https:'||upstream.username||upstream.password)throw Error('INVALID_ISSUER_OR_API_OR_REDIRECT');
 if(issuer.origin===redirect.origin)throw Error('ISSUER_AND_CLIENT_MUST_BE_SEPARATE_HOSTS');
 if(env.OIDC_CLIENT_SECRET.length<32||env.IAM_WORKLOAD_KEY.length<32||env.IAM_EOC_BRIDGE_KEY.length<32)throw Error('SHORT_SECRET');
 if(env.OIDC_COOKIE_KEYS.split(',').filter(x=>x.trim().length>=32).length<2)throw Error('COOKIE_KEY_ROTATION_NOT_CONFIGURED');
 if(!env.IAM_CA_FILE||!env.IAM_CLIENT_CERT||!env.IAM_CLIENT_KEY)throw Error('MTLS_CONFIGURATION_REQUIRED');
 if(env.OIDC_PRODUCTION_ENABLED!=='true')throw Error('ISSUER_DISABLED_UNTIL_CERTIFIED');
 return {issuer:issuer.origin,redirect:redirect.href};
}
export function assertPkce(params){
 if(params.response_type!=='code'||params.code_challenge_method!=='S256'||typeof params.code_challenge!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(params.code_challenge))throw Error('PKCE_S256_REQUIRED');
 if(!String(params.scope||'').split(/\s+/).includes('openid'))throw Error('OPENID_SCOPE_REQUIRED');
 return true;
}
export function assertFreshOidcRequest(params){
 if(String(params?.max_age)!=='0'||!String(params?.prompt||'').split(/\s+/).includes('login'))throw Error('FRESH_PASSKEY_LOGIN_REQUIRED');
 if(!String(params?.acr_values||'').split(/\s+/).includes(REQUIRED_ACR))throw Error('REQUIRED_ACR_MISSING');
 return true;
}
export function assertPasskeyProof(proof,{requestId,issuer,expectedChallengeId,interactionId,now=Date.now()}={}){
 if(!proof||proof.verifier!=='TCDS_CENTRAL_IAM_WEBAUTHN'||proof.action!=='EOC_OIDC_LOGIN'||proof.issuer!==issuer||proof.requestId!==requestId||proof.challengeId!==expectedChallengeId||(interactionId!==undefined&&proof.interactionId!==interactionId))throw Error('IAM_PASSKEY_PROOF_BINDING_INVALID');
 if(typeof proof.subject!=='string'||!/^[-A-Za-z0-9._~]{16,255}$/.test(proof.subject))throw Error('INVALID_SUBJECT');
 if(proof.userVerified!==true||proof.rpVerified!==true||proof.originVerified!==true||proof.counterOrBackupPolicyPassed!==true||proof.credentialActive!==true||proof.accountActive!==true||proof.bindingVerified!==true)throw Error('CENTRAL_IAM_PASSKEY_ASSURANCE_FAILED');
 if(proof.acr!==REQUIRED_ACR||!Array.isArray(proof.amr)||!proof.amr.includes('webauthn')||!proof.amr.includes('user_verification'))throw Error('ACR_AMR_NOT_ATTESTED');
 if(!Number.isInteger(proof.authTime)||proof.authTime<Math.floor(now/1000)-120||proof.authTime>Math.floor(now/1000)+5||!Number.isInteger(proof.expiresAt)||proof.expiresAt*1000<=now||proof.expiresAt>Math.floor(now/1000)+120)throw Error('PROOF_STALE');
 if(typeof proof.evidenceId!=='string'||proof.evidenceId.length<8||proof.evidenceId.length>160||!(/^[A-Za-z0-9_-]+$/.test(proof.evidenceId))||!(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(proof.iamUserId||'')))throw Error('PROOF_EVIDENCE_MISSING');
 return {accountId:proof.subject,iamUserId:proof.iamUserId,evidenceId:proof.evidenceId,acr:REQUIRED_ACR,amr:['webauthn','user_verification'],ts:proof.authTime,remember:false};
}
export function hashHex(s){return createHash('sha256').update(s).digest('hex')}
export function constantEqual(a,b){if(typeof a!=='string'||typeof b!=='string')return false;const x=Buffer.from(a),y=Buffer.from(b);return x.length===y.length&&timingSafeEqual(x,y)}
export function safeUid(v){return typeof v==='string'&&/^[A-Za-z0-9_-]{8,160}$/.test(v)}
