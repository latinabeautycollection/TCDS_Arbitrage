import https from 'node:https';
import {createHash,createHmac,randomBytes} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {assertPasskeyProof} from './policy.mjs';
function canonical(method,path,stamp,nonce,bytes){return `${method}\n${path}\n${stamp}\n${nonce}\n${createHash('sha256').update(bytes).digest('hex')}`}
export function signWorkload(key,method,path,stamp,nonce,raw){return createHmac('sha256',key).update(canonical(method,path,stamp,nonce,raw)).digest('hex')}
export function createIamVerifier(env,post=securePost){
 const base=new URL(env.IAM_PASSKEY_API_URL);if(base.protocol!=='https:')throw Error('IAM_MUST_BE_HTTPS');
 const signing=env.IAM_WORKLOAD_KEY;
 const bridgeKey=env.IAM_EOC_BRIDGE_KEY;
 async function call(op,body){
  const path=`/internal/v1/iam/oidc/passkey/${op}`,url=new URL(path,base),raw=Buffer.from(JSON.stringify(body)),stamp=String(Math.floor(Date.now()/1000)),nonce=randomBytes(20).toString('hex');
  const headers={'content-type':'application/json','content-length':String(raw.length),'x-eoc-workload-timestamp':stamp,'x-eoc-workload-nonce':nonce,'x-eoc-workload-signature':signWorkload(signing,'POST',path,stamp,nonce,raw)};
  return post(url,{raw,headers,caFile:env.IAM_CA_FILE,certFile:env.IAM_CLIENT_CERT,keyFile:env.IAM_CLIENT_KEY});
 }
 return {
  readiness:async()=>{
   if(!bridgeKey||bridgeKey.length<32)throw Error('IAM_EOC_BRIDGE_KEY_REQUIRED');
   const path='/internal/v1/iam/eoc/ready',stamp=String(Math.floor(Date.now()/1000)),nonce=randomBytes(20).toString('hex'),raw=Buffer.alloc(0);
   const upstream=new URL(env.IAM_EOC_BRIDGE_API_URL||env.IAM_PASSKEY_API_URL);
   const result=await post(new URL(path,upstream),{method:'GET',raw,headers:{'x-eoc-workload-timestamp':stamp,'x-eoc-workload-nonce':nonce,'x-eoc-workload-signature':signWorkload(bridgeKey,'GET',path,stamp,nonce,raw)},caFile:env.IAM_CA_FILE,certFile:env.IAM_CLIENT_CERT,keyFile:env.IAM_CLIENT_KEY});
   if(result?.ready!==true||result.epochAuthority!==true||result.federationAuthority!==true)throw Error('IAM_BRIDGE_UNREADY');
   return true;
  },
  begin:({interactionId,requestId,issuer})=>call('begin',{interactionId,requestId,issuer,purpose:'EOC_OIDC_LOGIN'}),
  checkSubject:async({issuer,subject})=>{
   if(!bridgeKey||bridgeKey.length<32)throw Error('IAM_EOC_BRIDGE_KEY_REQUIRED');
   if(typeof subject!=='string'||!/^[-A-Za-z0-9._~]{16,255}$/.test(subject))throw Error('FEDERATION_SUBJECT_INVALID');
   if(typeof issuer!=='string'||!issuer.startsWith('https://'))throw Error('FEDERATION_ISSUER_INVALID');
   const bridgeBase=new URL(env.IAM_EOC_BRIDGE_API_URL||env.IAM_PASSKEY_API_URL);
   if(bridgeBase.protocol!=='https:')throw Error('BRIDGE_HTTPS_REQUIRED');
   const resolvePath='/internal/v1/iam/eoc/federation/resolve';
   const raw=Buffer.from(JSON.stringify({issuer,providerSubject:subject}));
   const stamp=String(Math.floor(Date.now()/1000)),nonce=randomBytes(20).toString('hex');
   const response=await post(new URL(resolvePath,bridgeBase),{raw,headers:{'content-type':'application/json','content-length':String(raw.length),'x-eoc-workload-timestamp':stamp,'x-eoc-workload-nonce':nonce,'x-eoc-workload-signature':signWorkload(bridgeKey,'POST',resolvePath,stamp,nonce,raw)},caFile:env.IAM_CA_FILE,certFile:env.IAM_CLIENT_CERT,keyFile:env.IAM_CLIENT_KEY});
   if(response?.verified!==true||!(/^[0-9a-f-]{36}$/i.test(response.userId||'')))throw Error('UNVERIFIED_FEDERATED_SUBJECT');
   const subjectPath='/internal/v1/iam/eoc/subject/'+response.userId;
   const stamp2=String(Math.floor(Date.now()/1000)),nonce2=randomBytes(20).toString('hex');
   const status=await post(new URL(subjectPath,bridgeBase),{method:'GET',raw:Buffer.alloc(0),headers:{'x-eoc-workload-timestamp':stamp2,'x-eoc-workload-nonce':nonce2,'x-eoc-workload-signature':signWorkload(bridgeKey,'GET',subjectPath,stamp2,nonce2,Buffer.alloc(0))},caFile:env.IAM_CA_FILE,certFile:env.IAM_CLIENT_CERT,keyFile:env.IAM_CLIENT_KEY});
   if(status?.userId!==response.userId||status?.active!==true||!Number.isSafeInteger(status?.epoch)||status.epoch<0)throw Error('IAM_SUBJECT_INACTIVE_OR_UNVERIFIED');
   return {userId:response.userId,epoch:status.epoch};
  },
  finish:async({interactionId,requestId,issuer,challengeId,credential})=>{
   const proof=await call('finish',{interactionId,requestId,issuer,challengeId,credential,purpose:'EOC_OIDC_LOGIN'});
   return assertPasskeyProof(proof,{requestId,issuer,interactionId,expectedChallengeId:challengeId});
  }
 };
}
export function securePost(url,{raw,headers,caFile,certFile,keyFile,method='POST'}){
 return new Promise((resolve,reject)=>{
  const req=https.request(url,{method,headers,ca:readFileSync(caFile),cert:readFileSync(certFile),key:readFileSync(keyFile),rejectUnauthorized:true,timeout:4000},res=>{
   let chunks=[],total=0;res.on('data',buf=>{total+=buf.length;if(total>32768){req.destroy(Error('IAM_RESPONSE_TOO_LARGE'));return}chunks.push(buf)});
   res.on('end',()=>{if(res.statusCode!==200)return reject(Error('IAM_VERIFIER_DENIED'));try{const value=JSON.parse(Buffer.concat(chunks).toString('utf8'));resolve(value)}catch{reject(Error('IAM_INVALID_RESPONSE'))}});
  });req.on('timeout',()=>req.destroy(Error('IAM_TIMEOUT')));req.on('error',reject);req.end(raw);
 });
}
